set serveroutput on size 500000
begin
  dbms_output.put_line('set_all_ranks...');
  set_all_ranks(5);
  dbms_output.put_line('-----------------');
  dbms_output.put_line('set_all_ranks2...');
  set_all_ranks2(3);
  dbms_output.put_line('-----------------');
  dbms_output.put_line('set_all_ranks3...');
  set_all_ranks3(4);
end;
/




/*======================================================================
| Supplement to the fifth edition of Oracle PL/SQL Programming by Steven
| Feuerstein with Bill Pribyl, Copyright (c) 1997-2009 O'Reilly Media, Inc. 
| To submit corrections or find more code samples visit
| http://oreilly.com/catalog/9780596514464/
*/